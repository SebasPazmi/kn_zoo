"""esto es un comentario"""
#Esto es un comentario
#Autor:Sebastián Pazmiño/Kenton Betancourt
#Que realiza el programa:
#Fecha:
#Variable espacio de memoria donde se va a guardar
#información y va a estar disponible mientras 
#se la necesite
"""print ("hola mundo")
#Creamos una variable 
numero=2
print("El numero es " ,numero)
print(type(numero))
numero3=3.4
print(type(numero3))
condicion=True
print(type(condicion))
nombre="Kenton/Sebastian"
print(type(nombre))"""

"""#como ingresar datos desde teclado
edad=int(input("ingresa la edad: "))
print(edad)
print(type(edad))"""


#como ingresar datos desde teclado nombre
"""nombres=str(input("ingresa el nombre: "))
print(nombres)
print(type(nombres))
edad=int(input("ingresa la edad: "))
print(edad)
print(type(edad))
print("los nombres son " +nombres +" y la edad es " , edad  )

#la funcion len perm9ite encontrar el 
#numero de elementos que tiene la variable tipo
#texto"""

"""nombres= "Saraaaaaaaa"
print(len(nombres))"""

#realizar un programa en python donde
#el usuario ingresa el nombre del estudiante 
#las 4 notas del modulo por teclado
#calcular el n1=22%, n2=22%, n3=22% y la n4=36%
#1 la condicion si la suma de la n1+n2+n3 es mayor a 3,6
#puede ingresar la nota 4, si el promedio de la suma 
#nota 1 nota 2 nota 3 y nota 4 es mayor a 5 y menor o igual a 6,99 se queda a suspenso
#y si loa suma de n1,n2,n3 y n4 es mayor o igual a 7 y menor o igual a 10
#pasa al siguiente nivel

nombre=str(input("ingresa el nombre: "))
print("su nombre es: " ,nombre)
print("ingrese las notas")
n1=(float(input("ingrese la nota 1: ")))*0.22
if n1<0:
      print("nota invalida")
else:print(n1)


n2=(float(input("ingrese la nota 2: ")))*0.22
if n2<0:
      print("nota invalida")
else:print(2)

n3=(float(input("ingrese la nota 3: ")))*0.22
if n3<0:
      print("nota invalida")
else:print(n3)

suma=n1+n2+n3

print("la suma de las 3 primeras notas es: " ,suma)


if suma>=3.6:

    print("puede ingresar la nota 4: ")
    

elif suma:2<=3.6
else:print("usted no puede igresar la nota 4, usted perdió la materia")








n4=(float(input("ingrese la nota 4: ")))*0.36
print(n4)
suma2=n1+n2+n3+n4
print("El promedio es: ",suma2)


if suma2>=7 and suma2<=10:
 print("usted pasa")


while suma2<6.99: print ("usted queda a suspenso") 

#else: suma2<=10 
#print("usted pasa")




"""if  suma<=3.6:
 print("usted no puede ingresar la nota 4, a perdido la materia: ")



if suma2>=5 and suma2<=6.99:
 print("usted queda suspenso")"""















