#Autor:Sebastián Pazmiño/Kenton Betancourt
#Que realiza el programa: calculo de un sistema de calificaciones   
#Fecha:20/07/2023
nombre=str(input("ingresa el nombre: "))
print("su nombre es: " ,nombre)
print("ingrese las notas")
n1=(float(input("ingrese la nota 1: ")))*0.22
if n1<0:
      print("nota invalida")
      exit(n1)
else:print(n1)


n2=(float(input("ingrese la nota 2: ")))*0.22
if n2<0:
      print("nota invalida")
      exit(n2)
else:print(2)

n3=(float(input("ingrese la nota 3: ")))*0.22
if n3<0:
      print("nota invalida")
      exit(n3)
else:print(n3)

suma=n1+n2+n3

print("la suma de las 3 primeras notas es: " ,suma)

if  suma<=3.6:
      print("No puede rendir el proyecto ya que su nota es : ",suma)
      exit(suma)
if suma>=3.6:

    print("puede ingresar la nota 4: ")
    n4=(float(input("ingrese la nota 4: ")))*0.36
    if n4<0:
      print("nota invalida")
      exit(n4)
   
   
    suma2=n1+n2+n3+n4
    print("El promedio es: ",suma2)




if suma2>=7 and suma2<=10:
      print("usted aprueba")

if suma2>=5 and suma2<=6.99:
      print("usted queda suspenso")
      




